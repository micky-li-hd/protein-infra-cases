# ProteinMPNN native training runtime

This package turns the published optimization patch into a self-contained training source tree. `reference/training/` is verbatim upstream commit `8907e6671bfbfc92303b5f79c4b5e6ce47cdef57`; `candidate/training/` differs only in `model_utils.py`. The candidate SHA256 is `df80b1bd880cacfa783f87d52f0f1b2d29808966313133b66fcdcd4386020fe9`, identical to the previously measured candidate.

Status: CPU checks only for this new launcher. No new GPU timing, full-data training, convergence result or four-gate certification has been obtained. The earlier 2.13× result remains scoped to the smaller steady-state benchmark. The full-size configuration below is untested and may exceed memory; an OOM must remain a failed run, not trigger silent batch or length reductions.

## Environment and data

Use Linux, Python 3.12.11, CUDA-compatible NVIDIA drivers and an isolated environment:

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
```

The pinned upstream [training documentation](https://github.com/dauparas/ProteinMPNN/blob/8907e6671bfbfc92303b5f79c4b5e6ce47cdef57/training/README.md) provides the full 16.5 GB dataset and a separate 47 MB test sample:

- Full: https://files.ipd.uw.edu/pub/training_sets/pdb_2021aug02.tar.gz
- Sample: https://files.ipd.uw.edu/pub/training_sets/pdb_2021aug02_sample.tar.gz

Obtain and extract the full dataset according to upstream instructions. Record the downloaded archive's SHA256 and use exactly the same extracted dataset for both arms. The launcher fingerprints split files and checks directory layout; it does not certify that all archive contents are present. A sample run is not a full-data result.

## Native training

`full_training.json` preserves the upstream v_48_020 training settings: 150 epochs, one million examples per load, token budget 10000, maximum length 10000, 48 neighbors, noise 0.2 and native mixed precision. It starts from scratch unless the same checkpoint is explicitly supplied to both arms.

Run layout and source checks without initializing CUDA:

```bash
.venv/bin/python train.py --variant reference --data /data/pdb_2021aug02 \
  --out runs/reference-seed1 --lock /shared/gpu_experiments.lock --check-only
```

Start one bounded process after verifying the GPU is assigned to this experiment:

```bash
.venv/bin/python train.py --variant reference --data /data/pdb_2021aug02 \
  --out runs/reference-seed1 --lock /shared/gpu_experiments.lock --gpu 0 --timeout 43200
.venv/bin/python audit_run.py runs/reference-seed1
```

Use `--variant candidate` and a fresh output directory to run the candidate. Keep recipe, seed, data, environment, GPU, checkpoint and timeout identical. The timeout is a resource bound, not permission to count partial training as complete. A full run may require a larger explicitly chosen bound; partial artifacts and failures are preserved.

The shared lock path must be the same path used by the other campaign launchers. The launcher fails immediately if another lock holder or GPU process is present. It does not stop other tasks or release GPU allocations. Linux pidfd cleanup reuses the existing OwnedProcesses mechanism and signals only processes with the exact per-launch nonce and verified process identity.

## Randomness and measurement

Both variants use identical main-process seeds, per-prefetch-call seeds and DataLoader worker NumPy seeds. This replaces upstream's entropy-seeded worker behavior in both arms. It does not establish exact input pairing by itself; the existing fixed-trajectory gate remains necessary. Native model, loss, optimizer, data loading, validation and checkpoint writing are retained.

`RESULT.json` reports process wall time including cold compilation and all native work. Inductor and Triton caches start in the new output directory for both arms. This differs from the earlier experiment's retained global Triton cache and must not be pooled with its timing samples. `audit_run.py` checks every reported epoch, counters, finite model and optimizer tensors, and cleanup. It does not award statistical equivalence or biological quality acceptance.

## Remaining acceptance work

1. Run the new package on a small, explicitly labeled fixture to check startup, checkpoint compatibility, ownership cleanup and both arms. Do not call this full training.
2. Re-run the existing frozen short-trajectory correctness and sensitivity controls before accepting a candidate build. Preserve their original margins and failure records.
3. Verify the complete dataset inventory. Run independent reference seeds and freeze a long-training quality comparison before using candidate results for acceptance. Report validation perplexity and sequence accuracy at matched epochs and update counts, plus held-out evaluation with its own frozen protocol.
4. Measure complete equal-workload processes and report cold and warm behavior separately. Keep OOMs, recompile failures and all reference repeats.

The code is derived from ProteinMPNN; its MIT license is included. No model weights or training data are redistributed here.
